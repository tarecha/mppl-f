-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 11, 2011 at 08:05 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eproc`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `Id_Berita` varchar(10) NOT NULL,
  `Judul` varchar(50) NOT NULL,
  `Isi` varchar(1000) NOT NULL,
  `File` varchar(20) NOT NULL,
  `Lokasi` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Berita`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--


-- --------------------------------------------------------

--
-- Table structure for table `data_kontrak`
--

CREATE TABLE IF NOT EXISTS `data_kontrak` (
  `Id_Kontrak` varchar(10) NOT NULL,
  `Nomor_surat_penawaran` varchar(10) NOT NULL,
  `Nomor_surat_penunjukkan_pemenang_barang_dan_jasa` varchar(10) NOT NULL,
  `Tanggal_surat_penunjukkan_pemenang_barang_dan_jasa` date NOT NULL,
  `Pihak_UIN` varchar(20) NOT NULL,
  `Pihak_penyedia` varchar(20) NOT NULL,
  `Nomor_kontrak` varchar(10) NOT NULL,
  `Tanggal_mulai_kontrak` date NOT NULL,
  `Tanggal_selesai_kontrak` date NOT NULL,
  `Tanggal_batas_pengiriman` date NOT NULL,
  `Id_Tawar` varchar(10) NOT NULL,
  PRIMARY KEY (`Id_Kontrak`),
  KEY `Id_Kontrak` (`Id_Kontrak`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_kontrak`
--


-- --------------------------------------------------------

--
-- Table structure for table `data_pelanggan`
--

CREATE TABLE IF NOT EXISTS `data_pelanggan` (
  `Id_Lelang` varchar(10) NOT NULL,
  `Id_Detail` varchar(10) NOT NULL,
  `Lokasi` varchar(20) NOT NULL,
  `Keterangan` varchar(20) NOT NULL,
  `File` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Lelang`),
  KEY `Id_Lelang` (`Id_Lelang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_pelanggan`
--


-- --------------------------------------------------------

--
-- Table structure for table `data_perusahaan`
--

CREATE TABLE IF NOT EXISTS `data_perusahaan` (
  `Id_perusahaan` varchar(10) NOT NULL,
  `Kualifikasi` varchar(20) NOT NULL,
  `Nama_perusahaan` varchar(20) NOT NULL,
  `Alamat` varchar(20) NOT NULL,
  `Provinsi` varchar(20) NOT NULL,
  `Kode-pos` varchar(10) NOT NULL,
  `Telepon` varchar(20) NOT NULL,
  `Fax` varchar(20) NOT NULL,
  `Penanggung_jawab` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Nama_pimpinan` varchar(20) NOT NULL,
  `NPIUP` varchar(20) NOT NULL,
  `SIUJK` varchar(20) NOT NULL,
  `Tanggal_terbit` date NOT NULL,
  `SIUP` varchar(20) NOT NULL,
  `Tanggal_terbit_SIUP` date NOT NULL,
  `Website` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_perusahaan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_perusahaan`
--


-- --------------------------------------------------------

--
-- Table structure for table `detail_pelanggan`
--

CREATE TABLE IF NOT EXISTS `detail_pelanggan` (
  `Id_Detail` varchar(10) NOT NULL,
  `Unit` varchar(20) NOT NULL,
  `Metode_pengadaan` varchar(20) NOT NULL,
  `Nama_pengadaan` varchar(20) NOT NULL,
  `Nomor_pengadaan` varchar(10) NOT NULL,
  `Id_Sub_bidang` varchar(10) NOT NULL,
  `Id_Kualifikasi` varchar(10) NOT NULL,
  `Keterangan_pengadaan` varchar(20) NOT NULL,
  `Id_Jadwal` varchar(10) NOT NULL,
  `Id_Jasa` varchar(10) NOT NULL,
  `Id_Material` varchar(10) NOT NULL,
  PRIMARY KEY (`Id_Detail`),
  KEY `Id_Detail` (`Id_Detail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_pelanggan`
--


-- --------------------------------------------------------

--
-- Table structure for table `jadwal_undangan`
--

CREATE TABLE IF NOT EXISTS `jadwal_undangan` (
  `Id_Jadwal` varchar(10) NOT NULL,
  `Tanggal` date NOT NULL,
  `Jam` time NOT NULL,
  `Tempat` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Jadwal`),
  KEY `Id_Jadwal` (`Id_Jadwal`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal_undangan`
--


-- --------------------------------------------------------

--
-- Table structure for table `jasa`
--

CREATE TABLE IF NOT EXISTS `jasa` (
  `Id_Jasa` varchar(10) NOT NULL,
  `Nama_jasa` varchar(20) NOT NULL,
  `Jumlah` varchar(20) NOT NULL,
  `Satuan` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Jasa`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jasa`
--


-- --------------------------------------------------------

--
-- Table structure for table `kualifikasi`
--

CREATE TABLE IF NOT EXISTS `kualifikasi` (
  `Id_Kualifikasi` varchar(10) NOT NULL,
  `Kualifikasi` varchar(20) NOT NULL,
  `Keterangan` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Kualifikasi`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kualifikasi`
--


-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE IF NOT EXISTS `material` (
  `Id_Material` varchar(10) NOT NULL,
  `Nama_material` varchar(20) NOT NULL,
  `Jenis_material` varchar(20) NOT NULL,
  `Jumlah` varchar(20) NOT NULL,
  `Satuan` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Material`),
  KEY `Id_Material` (`Id_Material`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `material`
--


-- --------------------------------------------------------

--
-- Table structure for table `sub_bidang`
--

CREATE TABLE IF NOT EXISTS `sub_bidang` (
  `Id_Sub_bidang` varchar(10) NOT NULL,
  `Nama_sub` varchar(20) NOT NULL,
  PRIMARY KEY (`Id_Sub_bidang`),
  KEY `Id_Sub_bidang` (`Id_Sub_bidang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_bidang`
--


-- --------------------------------------------------------

--
-- Table structure for table `tawar`
--

CREATE TABLE IF NOT EXISTS `tawar` (
  `Id_Tawar` varchar(10) NOT NULL,
  `Id_Perusahaan` varchar(10) NOT NULL,
  `Id_Lelang` varchar(10) NOT NULL,
  `Tanggal_lelang` date NOT NULL,
  PRIMARY KEY (`Id_Tawar`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tawar`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `Nama_pengguna` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`Nama_pengguna`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

